#Run build step for paper and export a pdf
#Justin Peterson, 06/17/15
pdflatex report
bibtex report
pdflatex report
pdflatex report
